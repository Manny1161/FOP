## Synopsis

Lecturer: Valerie Maxville
Tutors: Isabelle & Cjacque & Sabrina

Assignment: Prac test
Unit name: Fundamentals of Programming
Unit id: COMP1005

## Contents

README - readme file for Practical test
test1.py - create a string and print it through a loop

## Dependencies

none

## Version information

20/08/2020 - date of practical session
