## Synopsis

Practical 5 of Fundamentals of Programming COMP1005/5005

## Contents

README - readme file for Practical 5

weather.py - print min and max temps
marchweather2.py - reading and writing temperature file
heat.py - plot heat diffusion 
heatsource.py - updated version of heat.py

heatsource.csv - values used for heatsource reading
marchout.csv - file written by marchweather2 program
marchweather.csv - file used for reading for marchweather2.py
marchweather2.csv  


## Dependencies

matlpotlib.pyplot
numpy

## Version information

13/09/2020
