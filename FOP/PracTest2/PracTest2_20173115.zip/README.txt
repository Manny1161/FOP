## Synopsis

Practical Test of Fundamentals of Programming COMP1005/5005

## Contents

Figure_1.png 
Figure_2.png
README.txt
test2f.py

## Dependencies

matplotlib.pyplot
numpy

## Version information

10/09/2020
