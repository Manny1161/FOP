## Synopsis

Practical 3 of Fundamentals of Programming COMP1005/5005

## Contents

README - readme file for Practical 2

dosage.py - decaying plot of figures (aspirin and concentration)
growthArray.py - array of growth
growthSubplot.py - subplot of growth
numberArray.py - array of numbers
numberBar.py - barchart of numbers
Prac3.1 - Unconstrained Growth PNG
Prac3.4 - Subplot PNG
Prac3.5 -  Numbers Bar Chart PNG

## Dependencies

none

## Version information

15/08/2020
