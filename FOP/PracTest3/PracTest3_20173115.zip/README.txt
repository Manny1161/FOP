## Synopsis

Lecturer: Valerie Maxville 
Tutors: Isabelle & Cjacque & Sabrina

Assignment: PracTest3
Unit Name: Fundamentals of Programming
Unit ID: COMP1005

## Content

README.txt - readme file for practical test
accounts.py - class for bank accounts
testAccounts.py - program to test functions of accounts.py

## Dependencies

none

## Version Information

08/10/2020 - date of practical session
