## Synopsis

Practical 4 of Fundamentals of Programming COMP1005/5005

## Contents

README - readme file for Practical 4

competitionv1.py
conversions.py
converter.py
prettyface.py
testconversions.py
zeros.py

## Dependencies

none

## Version information

03/09/2020
